/**
 * La clase Estacion representa una estación en la ruta del tren.
 * Cada estación tiene un nombre y colas separadas para pasajeros discapacitados y no discapacitados.
 */
public class Estacion {
    // Nombre de la estación
    private String nombre;

    // Cola de pasajeros discapacitados
    private Cola colaDiscapacitados;

    // Cola de pasajeros no discapacitados
    private Cola colaNoDiscapacitados;

    /**
     * constructor de la clase Estacion
     */
    public Estacion(String nombre) {
        this.nombre = nombre;
        this.colaDiscapacitados = new Cola();
        this.colaNoDiscapacitados = new Cola();
    }

    /**
     * Obtiene el nombre de la estación.
     *
     * @return El nombre de la estación.
     */
    public String getNombre() {
        return nombre;
    }

    /**
     * Obtiene la cola de pasajeros discapacitados.
     *
     * @return La cola de pasajeros discapacitados.
     */
    public Cola getColaDiscapacitados() {
        return colaDiscapacitados;
    }

    /**
     * Obtiene la cola de pasajeros no discapacitados.
     *
     * @return La cola de pasajeros no discapacitados.
     */
    public Cola getColaNoDiscapacitados() {
        return colaNoDiscapacitados;
    }
}


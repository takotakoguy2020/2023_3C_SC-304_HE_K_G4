/**
 * La clase ListaCircularDoble representa una lista circular doblemente enlazada.
 * Se utiliza para gestionar la distribución de pasajeros en pilas en el contexto del proyecto.
 */
public class ListaCircularDoble {
    // Referencia al primer nodo de la lista circular doble
    private NodoListaCircularDoble primero;

    /**
     * Constructor de la clase ListaCircularDoble.
     * Inicializa la lista como vacía.
     */
    public ListaCircularDoble() {
        this.primero = null;
    }

    /**
     * Verifica si la lista circular doble está vacía.
     *
     * @return true si la lista está vacía, false en caso contrario.
     */
    public boolean isEmpty() {
        return primero == null;
    }

    /**
     * Inserta un nuevo nodo al final de la lista circular doble con el dato proporcionado.
     *
     * @param dato Dato a almacenar en el nuevo nodo.
     */
    public void insertarAlFinal(Object dato) {
        NodoListaCircularDoble nuevoNodo = new NodoListaCircularDoble(dato);
        if (isEmpty()) {
            primero = nuevoNodo;
        } else {
            NodoListaCircularDoble ultimo = primero.getAnterior();
            nuevoNodo.setSiguiente(primero);
            nuevoNodo.setAnterior(ultimo);
            primero.setAnterior(nuevoNodo);
            ultimo.setSiguiente(nuevoNodo);
        }
    }

    /**
     * Obtiene la referencia al primer nodo de la lista circular doble.
     *
     * @return Referencia al primer nodo.
     */
    public NodoListaCircularDoble getPrimero() {
        return primero;
    }

    /**
     * Muestra el contenido de la lista circular doble.
     * Imprime en consola los datos almacenados en cada nodo de la lista.
     */
    public void mostrarContenido() {
        if (!isEmpty()) {
            NodoListaCircularDoble actual = primero;
            do {
                System.out.println(actual.getDato());
                actual = actual.getSiguiente();
            } while (actual != primero);
        } else {
            System.out.println("La lista está vacía.");
        }
    }

    /**
     * Distribuye pasajeros en las pilas proporcionadas según su condición de discapacidad.
     * Los pasajeros con discapacidad se insertan en la primera pila, mientras que los demás
     * se insertan en la segunda pila.
     *
     * @param pilas              Arreglo de pilas donde se distribuirán los pasajeros.
     * @param colaDiscapacitados Cola de pasajeros discapacitados.
     * @param colaNoDiscapacitados Cola de pasajeros no discapacitados.
     */
    public void distribuirPasajerosEnPilas(Pila[] pilas, Cola colaDiscapacitados, Cola colaNoDiscapacitados) {
        if (!isEmpty()) {
            NodoListaCircularDoble actual = primero;
            do {
                Pasajero pasajero = (Pasajero) actual.getDato();
                if (pasajero.isDiscapacitado()) {
                    if (!colaDiscapacitados.isEmpty()) {
                        pilas[0].push(colaDiscapacitados.desencolar());
                    }
                } else {
                    if (!colaNoDiscapacitados.isEmpty()) {
                        pilas[1].push(colaNoDiscapacitados.desencolar());
                    }
                }

                actual = actual.getSiguiente();
            } while (actual != primero);
        }
    }
}



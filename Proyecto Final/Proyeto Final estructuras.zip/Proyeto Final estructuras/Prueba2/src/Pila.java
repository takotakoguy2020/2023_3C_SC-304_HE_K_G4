/**
 * La clase Pila representa una pila de pasajeros en el tren, organizada de acuerdo a la prioridad
 * de asientos. Cada pila tiene una capacidad máxima, un indicador de capacidad para pasajeros
 * discapacitados, y un tamaño actual que indica la cantidad de pasajeros en la pila.
 */
public class Pila {
    private NodoPila cima; // Nodo superior de la pila
    private int capacidad; // Capacidad máxima de la pila
    private int size; // Tamaño actual de la pila
    private boolean discapacitado; // Indica si la pila es exclusiva para pasajeros discapacitados

    /**
     * Obtiene el nodo superior (cima) de la pila.
     *
     * @return El nodo superior de la pila.
     */
    public NodoPila getCima() {
        return cima;
    }

    /**
     * Obtiene la capacidad máxima de la pila.
     *
     * @return La capacidad máxima de la pila.
     */
    public int getCapacidad() {
        return capacidad;
    }

    /**
     * Obtiene el tamaño actual de la pila.
     *
     * @return El tamaño actual de la pila.
     */
    public int getSize() {
        return size;
    }

    /**
     * Establece el nodo superior (cima) de la pila.
     *
     * @param cima El nuevo nodo superior de la pila.
     */
    public void setCima(NodoPila cima) {
        this.cima = cima;
    }

    /**
     * Verifica si la pila es exclusiva para pasajeros discapacitados.
     *
     * @return true si la pila es para discapacitados, false en caso contrario.
     */
    public boolean isDiscapacitado() {
        return discapacitado;
    }

    /**
     * Establece si la pila es exclusiva para pasajeros discapacitados.
     *
     * @param discapacitado true si la pila es para discapacitados, false en caso contrario.
     */
    public void setDiscapacitado(boolean discapacitado) {
        this.discapacitado = discapacitado;
    }

    /**
     * Constructor que crea una nueva pila con la capacidad y la indicación de discapacidad proporcionadas.
     *
     * @param capacidad      La capacidad máxima de la pila.
     * @param discapacitado  Indica si la pila es exclusiva para pasajeros discapacitados.
     */
    public Pila(int capacidad, boolean discapacitado) {
        this.cima = null;
        this.capacidad = capacidad;
        this.discapacitado = discapacitado;
        this.size = 0;
    }

    /**
     * Verifica si la pila está vacía.
     *
     * @return true si la pila está vacía, false en caso contrario.
     */
    public boolean isEmpty() {
        return cima == null;
    }

    /**
     * Verifica si la pila está llena.
     *
     * @return true si la pila está llena, false en caso contrario.
     */
    public boolean isFull() {
        return size == capacidad;
    }

    /**
     * Agrega un nuevo pasajero a la pila si no está llena.
     *
     * @param pasajero El pasajero a agregar a la pila.
     */
    public void push(Pasajero pasajero) {
        if (!isFull()) {
            NodoPila nuevoNodo = new NodoPila(pasajero);
            nuevoNodo.setSiguiente(cima);
            cima = nuevoNodo;
            size++;
        } else {
            System.out.println("La pila está llena. No se puede agregar más pasajeros.");
        }
    }

    /**
     * Extrae y devuelve al pasajero en la cima de la pila si no está vacía.
     *
     * @return El pasajero desapilado, o null si la pila está vacía.
     */
    public Pasajero pop() {
        if (!isEmpty()) {
            Pasajero pasajeroDesapilado = cima.getPasajero();
            cima = cima.getSiguiente();
            size--;
            return pasajeroDesapilado;
        } else {
            System.out.println("La pila está vacía. No se puede desapilar.");
            // Puedes lanzar una excepción en lugar de imprimir un mensaje si lo prefieres
            return null;
        }
    }

    /**
     * Elimina los pasajeros cuya estación de destino coincide con la estación proporcionada.
     *
     * @param estacion La estación a la que llega el tren.
     */
    public void bajarPasajeros(int estacion) {
        if (cima == null) return;
        NodoPila actual = this.getCima();
        NodoPila anterior = null;
        while (actual != null) {
            if (actual.getPasajero().getEstacionDestino() == estacion) {
                System.out.println("El pasajero " + actual.getPasajero().getNombre() + " " + actual.getPasajero().getApellidos() + " se ha bajado");
                if (anterior != null) {
                    anterior.setSiguiente(actual.getSiguiente());
                    actual.setSiguiente(null);
                    actual = null;
                } else {
                    this.setCima(actual.getSiguiente());
                    actual.setSiguiente(null);
                    actual = null;
                    break;
                }
            }
            anterior = actual;
            actual = actual.getSiguiente();
        }
    }

    /**
     * Muestra el contenido de la pila en la consola.
     */
    public void mostrarContenido() {
        NodoPila nodoActual = cima;
        while (nodoActual != null) {
            Pasajero pasajero = nodoActual.getPasajero();
            System.out.println(pasajero.getNombre() + " " + pasajero.getApellidos());
            nodoActual = nodoActual.getSiguiente();
        }
    }
}




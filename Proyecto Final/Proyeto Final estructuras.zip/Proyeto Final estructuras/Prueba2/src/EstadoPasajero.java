public enum EstadoPasajero {
    EN_COLA,
    EN_CAMINO,
    COMPLETADO
}


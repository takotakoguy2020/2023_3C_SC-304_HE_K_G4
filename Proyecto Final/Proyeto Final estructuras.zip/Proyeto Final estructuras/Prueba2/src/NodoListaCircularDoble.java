/**
 * La clase NodoListaCircularDoble representa un nodo en una lista circular doble.
 * Cada nodo contiene un dato, así como referencias al siguiente y al anterior nodo en la lista.
 */
public class NodoListaCircularDoble {
    private Object dato; // Dato almacenado en el nodo
    private NodoListaCircularDoble siguiente; // Referencia al siguiente nodo
    private NodoListaCircularDoble anterior; // Referencia al nodo anterior

    /**
     * Constructor que crea un nuevo nodo con el dato especificado.
     *
     * @param dato El dato almacenado en el nodo.
     */
    public NodoListaCircularDoble(Object dato) {
        this.dato = dato;
        this.siguiente = this; // Inicialmente apunta a sí mismo en ambas direcciones
        this.anterior = this; // Inicialmente apunta a sí mismo en ambas direcciones
    }

    /**
     * Obtiene el dato almacenado en el nodo.
     *
     * @return El dato almacenado en el nodo.
     */
    public Object getDato() {
        return dato;
    }

    /**
     * Obtiene la referencia al siguiente nodo en la lista.
     *
     * @return El siguiente nodo en la lista.
     */
    public NodoListaCircularDoble getSiguiente() {
        return siguiente;
    }

    /**
     * Establece la referencia al siguiente nodo en la lista.
     *
     * @param siguiente El siguiente nodo en la lista.
     */
    public void setSiguiente(NodoListaCircularDoble siguiente) {
        this.siguiente = siguiente;
    }

    /**
     * Obtiene la referencia al nodo anterior en la lista.
     *
     * @return El nodo anterior en la lista.
     */
    public NodoListaCircularDoble getAnterior() {
        return anterior;
    }

    /**
     * Establece la referencia al nodo anterior en la lista.
     *
     * @param anterior El nodo anterior en la lista.
     */
    public void setAnterior(NodoListaCircularDoble anterior) {
        this.anterior = anterior;
    }
}


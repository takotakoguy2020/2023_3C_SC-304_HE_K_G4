public enum Vertices {
    ALAJUELA,
    LIMON,
    CARTAGO,
    HEREDIA,
    SAN_JOSE,
    PUNTARENAS,
    GUANACASTE
}


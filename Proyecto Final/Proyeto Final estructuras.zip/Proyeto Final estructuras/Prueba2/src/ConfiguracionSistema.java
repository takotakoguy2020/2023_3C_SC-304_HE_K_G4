import java.io.FileReader;
import java.io.IOException;
import java.util.Properties;

/**
 * La clase ConfiguracionSistema carga y almacena la configuración del sistema desde un archivo de propiedades.
 */
public class ConfiguracionSistema {

    // Valores predeterminados para la configuración del sistema
    private static int filasConDiscapacidad = 1;
    private static int filasSinDiscapacidad = 2;
    private static int asientosFilaConDiscapacidad = 1;
    private static int asientosFilaSinDiscapacidad = 3;
    private static String nombreEmpresa = "Nombre Empresa";
    private static int tiempoAvanceTren = 1;
    private static int costoPorKilometro = 100;

    /**
     * Carga la configuración del sistema desde el archivo de propiedades (configuracion.ini).
     * Si hay algún error al cargar la configuración, se utilizan los valores predeterminados.
     */
    public static void cargarConfiguracion() {
        Properties properties = new Properties();
        try (FileReader reader = new FileReader("configuracion.ini")) {
            properties.load(reader);

            filasConDiscapacidad = Integer.parseInt(properties.getProperty("filasConDiscapacidad", String.valueOf(filasConDiscapacidad)));
            filasSinDiscapacidad = Integer.parseInt(properties.getProperty("filasSinDiscapacidad", String.valueOf(filasSinDiscapacidad)));
            asientosFilaConDiscapacidad = Integer.parseInt(properties.getProperty("asientosFilaConDiscapacidad", String.valueOf(asientosFilaConDiscapacidad)));
            asientosFilaSinDiscapacidad = Integer.parseInt(properties.getProperty("asientosFilaSinDiscapacidad", String.valueOf(asientosFilaSinDiscapacidad)));
            nombreEmpresa = properties.getProperty("nombreEmpresa", nombreEmpresa);
            tiempoAvanceTren = Integer.parseInt(properties.getProperty("tiempoAvanceTren", String.valueOf(tiempoAvanceTren)));
            costoPorKilometro = Integer.parseInt(properties.getProperty("costoPorKilometro", String.valueOf(costoPorKilometro)));
        } catch (IOException e) {
            System.err.println("Error al cargar la configuración. Se utilizarán los valores predeterminados.");
            e.printStackTrace();
        }
    }

    // Métodos de acceso para obtener los valores de configuración

    public static int getFilasConDiscapacidad() {
        return filasConDiscapacidad;
    }

    public static int getFilasSinDiscapacidad() {
        return filasSinDiscapacidad;
    }

    public static int getAsientosFilaConDiscapacidad() {
        return asientosFilaConDiscapacidad;
    }

    public static int getAsientosFilaSinDiscapacidad() {
        return asientosFilaSinDiscapacidad;
    }

    public static String getNombreEmpresa() {
        return nombreEmpresa;
    }

    public static int getTiempoAvanceTren() {
        return tiempoAvanceTren;
    }

    public static int getCostoPorKilometro() {
        return costoPorKilometro;
    }
}




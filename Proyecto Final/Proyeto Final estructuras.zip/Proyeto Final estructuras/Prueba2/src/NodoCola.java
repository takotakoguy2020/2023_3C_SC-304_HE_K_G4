/**
 * La clase NodoCola representa un nodo de una cola en una estructura de datos.
 * Cada nodo contiene un objeto de tipo Pasajero y una referencia al siguiente nodo en la cola.
 */
public class NodoCola {
    private Pasajero pasajero; // Pasajero almacenado en el nodo
    private NodoCola siguiente; // Referencia al siguiente nodo en la cola

    /**
     * Constructor que crea un nuevo nodo con el pasajero especificado.
     *
     * @param pasajero El pasajero a almacenar en el nodo.
     */
    public NodoCola(Pasajero pasajero) {
        this.pasajero = pasajero;
        this.siguiente = null; // Inicializa la referencia al siguiente nodo como nula.
    }

    /**
     * Obtiene el pasajero almacenado en el nodo.
     *
     * @return El pasajero almacenado en el nodo.
     */
    public Pasajero getPasajero() {
        return pasajero;
    }

    /**
     * Obtiene la referencia al siguiente nodo en la cola.
     *
     * @return La referencia al siguiente nodo en la cola.
     */
    public NodoCola getSiguiente() {
        return siguiente;
    }

    /**
     * Establece la referencia al siguiente nodo en la cola.
     *
     * @param siguiente El siguiente nodo en la cola.
     */
    public void setSiguiente(NodoCola siguiente) {
        this.siguiente = siguiente;
    }
}



import javax.swing.*;

/**
 * La clase Main es la clase principal del programa que inicia la simulación del movimiento de un tren.
 * Permite la interacción con el usuario a través de cuadros de diálogo para ingresar detalles de los pasajeros
 * y controlar el flujo del programa.
 */
public class Main {
    /**
     * Método principal que inicia la simulación del tren y gestiona la interacción con el usuario.
     *
     * @param args Los argumentos de la línea de comandos (no se utilizan en este caso).
     */
    public static void main(String[] args) {
        // Carga la configuración del sistema
        ConfiguracionSistema.cargarConfiguracion();

        // Crea un grafo para representar las conexiones entre estaciones
        Grafo grafo = new Grafo(7);

        // Configuración de las aristas con sus respectivos pesos
        grafo.setArista(0, 1, new int[]{40, 25}); // Alajuela - Limón
        grafo.setArista(1, 2, new int[]{10, 20}); // Limón - Cartago
        grafo.setArista(2, 3, new int[]{50, 60}); // Cartago - Heredia
        grafo.setArista(3, 4, new int[]{30, 30}); // Heredia - San José
        grafo.setArista(4, 5, new int[]{25, 35}); // San José - Puntarenas
        grafo.setArista(5, 6, new int[]{40, 40}); // Puntarenas - Guanacaste
        grafo.setArista(6, 0, new int[]{100, 120}); // Guanacaste - Alajuela

        // Crear un arreglo de estaciones
        Estacion[] estaciones = {new Estacion("Alajuela"), new Estacion("Limón"), new Estacion("Cartago"), new Estacion("Heredia"), new Estacion("San José"), new Estacion("Puntarenas"), new Estacion("Guanacaste")};

        // Crear un vagon de tren con la configuración del sistema, el grafo y las estaciones
        VagonTren vagon = new VagonTren(ConfiguracionSistema.getFilasConDiscapacidad(), ConfiguracionSistema.getFilasSinDiscapacidad(), grafo, estaciones);

        // Iniciar el hilo del vagon
        vagon.start();

        // Ciclo de interacción con el usuario
        while (true) {
            // Solicitar información del pasajero mediante cuadros de diálogo
            String nombre = JOptionPane.showInputDialog(null, "Nombre del cliente", "Ingreso", JOptionPane.QUESTION_MESSAGE);
            if (nombre == null) System.exit(0); // Salir del programa si se cancela la entrada de nombre
            String apellidos = JOptionPane.showInputDialog(null, "Apellidos del cliente", "Ingreso", JOptionPane.QUESTION_MESSAGE);
            if (apellidos == null) continue; // Regresar al inicio del bucle si se cancela la entrada de apellidos
            int edad = 0;
            while (true) {
                try {
                    // Solicitar la edad y manejar posibles excepciones
                    String edadString = JOptionPane.showInputDialog(null, "Edad del cliente", "Ingreso", JOptionPane.QUESTION_MESSAGE);
                    if (edadString == null) continue; // Regresar al inicio del bucle si se cancela la entrada de edad
                    edad = Integer.parseInt(edadString);
                    break; // Salir del bucle si la entrada es válida
                } catch (Exception e) {
                    JOptionPane.showMessageDialog(null, "La edad debe de ser un número", "ERROR", JOptionPane.ERROR_MESSAGE);
                }
            }

            // Solicitar la estación de origen y destino mediante cuadros de diálogo
            String[] opciones = {"Alajuela", "Limón", "Cartago", "Heredia", "San José", "Puntarenas", "Guanacaste"};
            int estacionOrigen = JOptionPane.showOptionDialog(null, "Seleccione la estación de origen", "Opciones", JOptionPane.DEFAULT_OPTION, JOptionPane.PLAIN_MESSAGE, null, opciones, opciones[0]);
            if (estacionOrigen == -1) continue; // Regresar al inicio del bucle si se cancela la selección de estación de origen
            int estacionDestino = JOptionPane.showOptionDialog(null, "Seleccione la estación de destino", "Opciones", JOptionPane.DEFAULT_OPTION, JOptionPane.PLAIN_MESSAGE, null, opciones, opciones[0]);
            if (estacionDestino == -1) continue; // Regresar al inicio del bucle si se cancela la selección de estación de destino

            // Determinar si el cliente es discapacitado
            boolean discapacitado = JOptionPane.showConfirmDialog(null, "El cliente es discapacitado?", "Pregunta", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE) == JOptionPane.YES_OPTION;

            // Crear un nuevo pasajero con la información proporcionada
            Pasajero pasajeroNuevo = new Pasajero(nombre, apellidos, edad, estacionOrigen, estacionDestino, discapacitado);

            // Encolar al pasajero en la cola correspondiente de la estación de origen
            if (discapacitado) {
                vagon.getEstaciones()[estacionOrigen].getColaDiscapacitados().encolar(pasajeroNuevo);
            } else {
                vagon.getEstaciones()[estacionOrigen].getColaNoDiscapacitados().encolar(pasajeroNuevo);
            }

            // Imprimir mensaje informativo en la consola
            System.out.println("El pasajero " + nombre + " " + apellidos + " está esperando en la estación " + opciones[estacionOrigen] + " (" + estacionOrigen + ") y quiere ir a " + opciones[estacionDestino] + " (" + estacionDestino + ")");
        }
    }
}


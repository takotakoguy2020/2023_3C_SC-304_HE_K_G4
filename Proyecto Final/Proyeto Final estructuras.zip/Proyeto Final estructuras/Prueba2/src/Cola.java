public class Cola {
    private NodoCola frente;
    private NodoCola finalCola;

    // Constructor de la clase Cola
    public Cola() {
        this.frente = null;
        this.finalCola = null;
    }

    // Método para obtener el frente de la cola
    public NodoCola getFrente() {
        return frente;
    }

    // Método para verificar si la cola está vacía
    public boolean isEmpty() {
        return frente == null;
    }

    // Método para encolar un pasajero
    public void encolar(Pasajero pasajero) {
        NodoCola nuevoNodo = new NodoCola(pasajero);
        if (isEmpty()) {
            // Si la cola está vacía, el frente y el final apuntan al nuevo nodo
            frente = nuevoNodo;
            finalCola = nuevoNodo;
        } else {
            // Si la cola no está vacía, se agrega el nuevo nodo al final y se actualiza el final
            finalCola.setSiguiente(nuevoNodo);
            finalCola = nuevoNodo;
        }
    }

    // Método para desencolar un pasajero
    public Pasajero desencolar() {
        if (!isEmpty()) {
            // Si la cola no está vacía, se obtiene el pasajero del frente
            Pasajero pasajeroDesencolado = frente.getPasajero();
            // Se mueve el frente al siguiente nodo
            frente = frente.getSiguiente();
            // Si después de desencolar la cola está vacía, se actualiza el final
            if (frente == null) {
                finalCola = null;
            }
            return pasajeroDesencolado;
        } else {
            // Si la cola está vacía, se imprime un mensaje y se devuelve null
            System.out.println("La cola está vacía. No se puede desencolar.");
            return null;
        }
    }

    // Método para mostrar el contenido de la cola
    public void mostrarContenido() {
        NodoCola nodoActual = frente;
        while (nodoActual != null) {
            Pasajero pasajero = nodoActual.getPasajero();
            // Se muestra el nombre y apellidos del pasajero
            System.out.println(pasajero.getNombre() + " " + pasajero.getApellidos());
            // Se avanza al siguiente nodo
            nodoActual = nodoActual.getSiguiente();
        }
    }
}




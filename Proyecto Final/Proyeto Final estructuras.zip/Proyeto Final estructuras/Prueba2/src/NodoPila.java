/**
 * La clase NodoPila representa un nodo en una estructura de datos de pila.
 * Cada nodo contiene un objeto Pasajero como dato, así como una referencia al siguiente nodo en la pila.
 */
public class NodoPila {
    private Pasajero pasajero; // Objeto Pasajero almacenado en el nodo
    private NodoPila siguiente; // Referencia al siguiente nodo en la pila

    /**
     * Constructor que crea un nuevo nodo con el objeto Pasajero especificado.
     *
     * @param pasajero El objeto Pasajero almacenado en el nodo.
     */
    public NodoPila(Pasajero pasajero) {
        this.pasajero = pasajero;
        this.siguiente = null;
    }

    /**
     * Obtiene el objeto Pasajero almacenado en el nodo.
     *
     * @return El objeto Pasajero almacenado en el nodo.
     */
    public Pasajero getPasajero() {
        return pasajero;
    }

    /**
     * Obtiene la referencia al siguiente nodo en la pila.
     *
     * @return El siguiente nodo en la pila.
     */
    public NodoPila getSiguiente() {
        return siguiente;
    }

    /**
     * Establece la referencia al siguiente nodo en la pila.
     *
     * @param siguiente El siguiente nodo en la pila.
     */
    public void setSiguiente(NodoPila siguiente) {
        this.siguiente = siguiente;
    }
}



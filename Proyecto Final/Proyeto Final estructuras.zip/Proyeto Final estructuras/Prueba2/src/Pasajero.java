/**
 * La clase Pasajero representa a un pasajero que viajará en el tren.
 * Cada pasajero tiene un nombre, apellidos, edad, estación de origen, estación de destino,
 * una indicación de discapacidad y un estado que puede cambiar durante el viaje.
 */
public class Pasajero {
    private String nombre; // Nombre del pasajero
    private String apellidos; // Apellidos del pasajero
    private int edad; // Edad del pasajero
    private int estacionOrigen; // Estación de origen del pasajero
    private int estacionDestino; // Estación de destino del pasajero
    private boolean discapacitado; // Indicación de discapacidad del pasajero
    private EstadoPasajero estado; // Estado actual del pasajero durante el viaje

    /**
     * Constructor que crea un nuevo Pasajero con la información proporcionada.
     *
     * @param nombre          El nombre del pasajero.
     * @param apellidos       Los apellidos del pasajero.
     * @param edad            La edad del pasajero.
     * @param estacionOrigen  La estación de origen del pasajero.
     * @param estacionDestino La estación de destino del pasajero.
     * @param discapacitado   Indica si el pasajero tiene alguna discapacidad.
     */
    public Pasajero(String nombre, String apellidos, int edad, int estacionOrigen, int estacionDestino, boolean discapacitado) {
        this.nombre = nombre;
        this.apellidos = apellidos;
        this.edad = edad;
        this.estacionOrigen = estacionOrigen;
        this.estacionDestino = estacionDestino;
        this.discapacitado = discapacitado;
        this.estado = EstadoPasajero.EN_COLA;
    }

    /**
     * Obtiene el nombre del pasajero.
     *
     * @return El nombre del pasajero.
     */
    public String getNombre() {
        return nombre;
    }

    /**
     * Obtiene los apellidos del pasajero.
     *
     * @return Los apellidos del pasajero.
     */
    public String getApellidos() {
        return apellidos;
    }

    /**
     * Obtiene la edad del pasajero.
     *
     * @return La edad del pasajero.
     */
    public int getEdad() {
        return edad;
    }

    /**
     * Obtiene la estación de origen del pasajero.
     *
     * @return La estación de origen del pasajero.
     */
    public int getEstacionOrigen() {
        return estacionOrigen;
    }

    /**
     * Obtiene la estación de destino del pasajero.
     *
     * @return La estación de destino del pasajero.
     */
    public int getEstacionDestino() {
        return estacionDestino;
    }

    /**
     * Verifica si el pasajero tiene alguna discapacidad.
     *
     * @return true si el pasajero tiene discapacidad, false en caso contrario.
     */
    public boolean isDiscapacitado() {
        return discapacitado;
    }

    /**
     * Obtiene el estado actual del pasajero durante el viaje.
     *
     * @return El estado actual del pasajero.
     */
    public EstadoPasajero getEstado() {
        return estado;
    }

    /**
     * Establece el estado del pasajero durante el viaje.
     *
     * @param estado El nuevo estado del pasajero.
     */
    public void setEstado(EstadoPasajero estado) {
        this.estado = estado;
    }

    /**
     * Sobrescribe el método toString para proporcionar una representación de cadena del objeto Pasajero.
     *
     * @return Representación de cadena del objeto Pasajero.
     */
    @Override
    public String toString() {
        return String.format(
                "Pasajero{nombre='%s', apellidos='%s', edad=%d, estacionOrigen='%s', estacionDestino='%s', discapacitado=%b, estado=%s}",
                nombre, apellidos, edad, estacionOrigen, estacionDestino, discapacitado, estado
        );
    }
}





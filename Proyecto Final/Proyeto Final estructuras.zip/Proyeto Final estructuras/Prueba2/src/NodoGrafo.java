/**
 * La clase NodoGrafo representa un nodo en la matriz de adyacencia de un grafo ponderado.
 * Cada nodo contiene un array de enteros que representa el peso de la arista entre dos vértices del grafo.
 */
public class NodoGrafo {
    private int[] peso; // Peso de la arista entre dos vértices

    /**
     * Constructor que crea un nuevo nodo con el peso especificado.
     *
     * @param peso El peso de la arista entre dos vértices.
     */
    public NodoGrafo(int[] peso) {
        this.peso = peso;
    }

    /**
     * Obtiene el peso de la arista entre dos vértices.
     *
     * @return El peso de la arista.
     */
    public int[] getPeso() {
        return this.peso;
    }
}



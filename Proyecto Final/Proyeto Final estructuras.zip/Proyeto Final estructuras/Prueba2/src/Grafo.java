/**
 * La clase Grafo representa un grafo ponderado con matriz de adyacencia.
 * Se utiliza para implementar el algoritmo de Dijkstra en el contexto del proyecto.
 */
public class Grafo {
    // Matriz de adyacencia que representa las aristas entre los vértices del grafo
    private final NodoGrafo matrizAdyacencia[][];

    // Número de vértices en el grafo
    private final int numVertices;

    /**
     * Constructor de la clase Grafo.
     *
     * @param numVertices Número de vértices en el grafo.
     */
    public Grafo(int numVertices) {
        this.numVertices = numVertices;
        this.matrizAdyacencia = new NodoGrafo[numVertices][numVertices];

        // Inicializar la matriz de adyacencia con valores nulos
        for (int i = 0; i < numVertices; i++) {
            for (int j = 0; j < numVertices; j++) {
                matrizAdyacencia[i][j] = null;
            }
        }
    }

    /**
     * Establece una arista entre dos vértices con un peso dado.
     *
     * @param i     Índice del vértice origen.
     * @param j     Índice del vértice destino.
     * @param peso  Arreglo de pesos asociados a la arista.
     */
    public void setArista(int i, int j, int[] peso) {
        matrizAdyacencia[i][j] = new NodoGrafo(peso);
    }

    /**
     * Elimina la arista entre dos vértices.
     *
     * @param i Índice del vértice origen.
     * @param j Índice del vértice destino.
     */
    public void eliminarArista(int i, int j) {
        matrizAdyacencia[i][j] = null;
    }

    /**
     * Encuentra el siguiente vértice no procesado en el grafo a partir de un origen dado.
     *
     * @param origen Índice del vértice de origen.
     * @return Índice del siguiente vértice no procesado, o -1 si no hay más vértices.
     */
    public int siguiente(int origen) {
        for (int i = 0; i < matrizAdyacencia.length; i++) {
            if (matrizAdyacencia[origen][i] != null) return i;
        }
        return -1;
    }

    /**
     * Implementación del algoritmo de Dijkstra para encontrar los caminos más cortos desde un origen dado.
     *
     * @param src Índice del vértice de origen.
     * @return Arreglo de distancias mínimas desde el vértice de origen a todos los demás vértices.
     */
    public int[] dijkstra(int src) {
        int[] dist = new int[numVertices];
        boolean[] verticeYaProcesado = new boolean[numVertices];

        // Inicializar distancias con un valor infinito y marcar todos los vértices como no procesados
        for (int i = 0; i < numVertices; i++) {
            dist[i] = Integer.MAX_VALUE;
            verticeYaProcesado[i] = false;
        }

        // La distancia desde el vértice de origen a sí mismo es siempre 0
        dist[src] = 0;

        // Procesar todos los vértices
        for (int count = 0; count < numVertices; count++) {
            // Encontrar el vértice no procesado con la distancia mínima
            int u = minDistance(dist, verticeYaProcesado);
            verticeYaProcesado[u] = true;

            // Actualizar las distancias de los vértices adyacentes no procesados
            for (int v = 0; v < numVertices; v++) {
                if (matrizAdyacencia[u][v] != null) {
                    if (!verticeYaProcesado[v] && matrizAdyacencia[u][v].getPeso()[1] > 0 &&
                            dist[u] != Integer.MAX_VALUE &&
                            dist[u] + matrizAdyacencia[u][v].getPeso()[1] < dist[v]) {
                        dist[v] = dist[u] + matrizAdyacencia[u][v].getPeso()[1];
                    }
                }
            }
        }
        return dist;
    }

    /**
     * Encuentra el vértice con la distancia mínima no procesada.
     *
     * @param dist                Arreglo de distancias mínimas.
     * @param verticeYaProcesado Arreglo que indica si un vértice ya ha sido procesado.
     * @return Índice del vértice con la distancia mínima no procesada.
     */
    private int minDistance(int[] dist, boolean[] verticeYaProcesado) {
        int min = Integer.MAX_VALUE;
        int min_index = 0;

        for (int v = 0; v < numVertices; v++) {
            if (!verticeYaProcesado[v] && dist[v] <= min) {
                min = dist[v];
                min_index = v;
            }
        }

        return min_index;
    }

    /**
     * Devuelve una representación de cadena del grafo.
     *
     * @return Cadena que representa la matriz de adyacencia del grafo.
     */
    @Override
    public String toString() {
        StringBuilder s = new StringBuilder();
        s.append("   ");
        for (int i = 0; i < numVertices; i++) {
            s.append(Vertices.values()[i]).append(" | ");
        }
        s.append("\n");
        for (int i = 0; i < numVertices; i++) {
            s.append(Vertices.values()[i]).append(": ");
            for (int j = 0; j < numVertices; j++) {
                if (matrizAdyacencia[i][j] != null) {
                    s.append(matrizAdyacencia[i][j].getPeso()).append(" | ");
                } else {
                    s.append("_ | ");
                }
            }
            s.append("\n");
        }
        return s.toString();
    }
}



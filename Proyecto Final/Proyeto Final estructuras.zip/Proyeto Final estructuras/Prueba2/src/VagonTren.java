import javax.swing.*;
import java.awt.*;

/**
 * La clase VagonTren representa el hilo del tren que realiza el recorrido entre estaciones.
 * Gestixdona la llegada a las estaciones, el ascenso y descenso de pasajeros, y la simulación del tiempo.
 */
public class VagonTren extends Thread {
    private ListaCircularDoble vagones; // Vagones del tren
    private int capacidadFilaDiscapacitados; // Capacidad de las filas para pasajeros discapacitados
    private int capacidadFilasNoDiscapacitados; // Capacidad de las filas para pasajeros no discapacitados
    private Estacion[] estaciones; // Arreglo de estaciones
    private Grafo grafoEstaciones; // Grafo que representa las conexiones entre estaciones

    /**
     * Obtiene el arreglo de estaciones asociado al tren.
     *
     * @return Arreglo de estaciones.
     */
    public Estacion[] getEstaciones() {
        return estaciones;
    }

    /**
     * Constructor que inicializa un nuevo tren con parámetros dados.
     *
     * @param capacidadFilaDiscapacitados   Capacidad de las filas para pasajeros discapacitados.
     * @param capacidadFilasNoDiscapacitados Capacidad de las filas para pasajeros no discapacitados.
     * @param grafoEstaciones               Grafo que representa las conexiones entre estaciones.
     * @param estaciones                    Arreglo de estaciones.
     */
    public VagonTren(int capacidadFilaDiscapacitados, int capacidadFilasNoDiscapacitados, Grafo grafoEstaciones, Estacion[] estaciones) {
        this.vagones = new ListaCircularDoble();
        this.capacidadFilaDiscapacitados = capacidadFilaDiscapacitados;
        this.capacidadFilasNoDiscapacitados = capacidadFilasNoDiscapacitados;
        this.grafoEstaciones = grafoEstaciones;
        this.estaciones = estaciones;
        inicializarVagones();
    }

    /**
     * Inicializa los vagones del tren con las capacidades especificadas.
     */
    private void inicializarVagones() {
        for (int i = 0; i < capacidadFilaDiscapacitados; i++) {
            Pila pilaDiscapacitados = new Pila(capacidadFilaDiscapacitados, true);
            vagones.insertarAlFinal(pilaDiscapacitados);
        }

        for (int i = 0; i < capacidadFilasNoDiscapacitados; i++) {
            Pila pilaNoDiscapacitados = new Pila(capacidadFilasNoDiscapacitados, false);
            vagones.insertarAlFinal(pilaNoDiscapacitados);
        }
    }

    /**
     * Meodo que se ejecuta en el hilo del tren, simula el recorrido y las acciones en las estaciones.
     */
    @Override
    public void run() {
        // Creación de la interfaz gráfica
        JFrame frame = new JFrame("Tren Simulador");
        frame.setLayout(new GridLayout(4, 1));
        frame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);

        JLabel tituloLabel = new JLabel(ConfiguracionSistema.getNombreEmpresa());
        tituloLabel.setFont(new Font("Arial", Font.BOLD, 24));

        JLabel minutoLabel = new JLabel("");
        minutoLabel.setFont(new Font("Arial", Font.PLAIN, 22));

        JLabel estacionLabel = new JLabel("");
        estacionLabel.setFont(new Font("Arial", Font.PLAIN, 22));

        frame.add(tituloLabel);
        frame.add(minutoLabel);
        frame.add(estacionLabel);
        frame.setVisible(true);
        frame.pack();

        int minutoActual = 0;
        int idEstacionActual = 0;
        int idEstacionSiguiente = grafoEstaciones.siguiente(idEstacionActual);

        try {
            while (true) {
                sleep(100); // Simulación del paso del tiempo
                estacionLabel.setText("Próxima estación: " + estaciones[idEstacionSiguiente].getNombre() + " (" + idEstacionSiguiente + ")");
                minutoActual++;
                minutoLabel.setText("Minutos: " + String.valueOf(minutoActual) + "/" + grafoEstaciones.dijkstra(idEstacionActual)[idEstacionSiguiente]);

                // Llegada a la siguiente estación
                if (grafoEstaciones.dijkstra(idEstacionActual)[idEstacionSiguiente] <= minutoActual) {
                    idEstacionActual = idEstacionSiguiente;
                    estacionLabel.setText("Estación Actual: " + estaciones[idEstacionActual].getNombre() + " (" + idEstacionActual + ")");
                    System.out.println("El tren ha llegado a la estación " + estaciones[idEstacionSiguiente].getNombre() + " (" + idEstacionSiguiente + ")");
                    idEstacionSiguiente = grafoEstaciones.siguiente(idEstacionActual);
                    minutoActual = 0;

                    // Descenso de pasajeros
                    NodoListaCircularDoble auxiliarAsientos = vagones.getPrimero();
                    ((Pila) auxiliarAsientos.getDato()).bajarPasajeros(idEstacionActual);
                    auxiliarAsientos = auxiliarAsientos.getSiguiente();
                    while (auxiliarAsientos != vagones.getPrimero()) {
                        ((Pila) auxiliarAsientos.getDato()).bajarPasajeros(idEstacionActual);
                        auxiliarAsientos = auxiliarAsientos.getSiguiente();
                    }

                    sleep(500);

                    // Ascenso de pasajeros discapacitados
                    NodoCola auxiliarDiscapacitados = estaciones[idEstacionActual].getColaDiscapacitados().getFrente();
                    while (auxiliarDiscapacitados != null) {
                        auxiliarAsientos = vagones.getPrimero();
                        if (((Pila) auxiliarAsientos.getDato()).getCapacidad() > ((Pila) auxiliarAsientos.getDato()).getSize()) {
                            System.out.println(auxiliarDiscapacitados.getPasajero().getNombre() + " " + auxiliarDiscapacitados.getPasajero().getApellidos() + " se ha subido al tren");
                            ((Pila) auxiliarAsientos.getDato()).push(auxiliarDiscapacitados.getPasajero());
                            estaciones[idEstacionActual].getColaDiscapacitados().desencolar();
                            auxiliarDiscapacitados = auxiliarDiscapacitados.getSiguiente();
                            continue;
                        }
                        auxiliarAsientos = auxiliarAsientos.getSiguiente();
                        while (auxiliarAsientos != vagones.getPrimero()) {
                            if (((Pila) auxiliarAsientos.getDato()).getCapacidad() > ((Pila) auxiliarAsientos.getDato()).getSize()) {
                                System.out.println(auxiliarDiscapacitados.getPasajero().getNombre() + " " + auxiliarDiscapacitados.getPasajero().getApellidos() + " se ha subido al tren");
                                ((Pila) auxiliarAsientos.getDato()).push(auxiliarDiscapacitados.getPasajero());
                                estaciones[idEstacionActual].getColaDiscapacitados().desencolar();
                                auxiliarDiscapacitados = auxiliarDiscapacitados.getSiguiente();
                                break;
                            }
                            auxiliarAsientos = auxiliarAsientos.getSiguiente();
                        }
                        auxiliarDiscapacitados = auxiliarDiscapacitados.getSiguiente();
                    }

                    // Ascenso de pasajeros no discapacitados
                    NodoCola auxiliarNoDiscapacitados = estaciones[idEstacionActual].getColaNoDiscapacitados().getFrente();
                    while (auxiliarNoDiscapacitados != null) {
                        auxiliarAsientos = vagones.getPrimero();
                        if (((Pila) auxiliarAsientos.getDato()).getCapacidad() > ((Pila) auxiliarAsientos.getDato()).getSize()) {
                            System.out.println(auxiliarNoDiscapacitados.getPasajero().getNombre() + " " + auxiliarNoDiscapacitados.getPasajero().getApellidos() + " se ha subido al tren");
                            ((Pila) auxiliarAsientos.getDato()).push(auxiliarNoDiscapacitados.getPasajero());
                            estaciones[idEstacionActual].getColaNoDiscapacitados().desencolar();
                            auxiliarNoDiscapacitados = auxiliarNoDiscapacitados.getSiguiente();
                            continue;
                        }
                        auxiliarAsientos = auxiliarAsientos.getSiguiente();
                        while (auxiliarAsientos != vagones.getPrimero()) {
                            if (((Pila) auxiliarAsientos.getDato()).getCapacidad() > ((Pila) auxiliarAsientos.getDato()).getSize()) {
                                System.out.println(auxiliarNoDiscapacitados.getPasajero().getNombre() + " " + auxiliarNoDiscapacitados.getPasajero().getApellidos() + " se ha subido al tren");
                                ((Pila) auxiliarAsientos.getDato()).push(auxiliarNoDiscapacitados.getPasajero());
                                estaciones[idEstacionActual].getColaNoDiscapacitados().desencolar();
                                auxiliarNoDiscapacitados = auxiliarNoDiscapacitados.getSiguiente();
                                break;
                            }
                            auxiliarAsientos = auxiliarAsientos.getSiguiente();
                        }
                        auxiliarNoDiscapacitados = auxiliarNoDiscapacitados.getSiguiente();
                    }
                    sleep(2000);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}



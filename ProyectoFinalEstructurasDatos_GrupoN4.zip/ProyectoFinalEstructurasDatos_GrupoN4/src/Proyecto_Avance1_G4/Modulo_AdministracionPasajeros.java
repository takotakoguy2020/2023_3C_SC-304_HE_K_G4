package Proyecto_Avance1_G4;

public class Modulo_AdministracionPasajeros {
    /*
    Módulo de ingreso de pasajeros
    1. El usuario debe tener la capacidad de agregar pasajeros según las necesidades y características
       de este.
    2. El usuario debe tener la capacidad de listar todos los pasajeros tanto en estaciones cómo en
       vagón del tren
    3. Datos del pasajero:
      a Nombre y apellidos
      b Edad
      c Estación origen
      d Estación destino
      e Discapacitado SI/NO, usando enum en java
      f Estado: EN_COLA/EN_CAMINO/COMPLETADO
    */
    
    
    
}//Fin de la clase

package ProyectoEstructuraDatos_Avance2_G4;

public class ColaEnEspera {
    private Nodo frente;
    private Nodo ultimo;

    public ColaEnEspera() {
        this.frente = null;
        this.ultimo = null;
    }

    public void agregarPasajero(Dato dato) {
        // Implementación para agregar un pasajero a la cola
        Nodo nuevoNodo = new Nodo(dato);
        if (frente == null) {
            frente = nuevoNodo;
            ultimo = nuevoNodo;
        } else {
            ultimo.setSiguiente(nuevoNodo);
            ultimo = nuevoNodo;
        }
    }

    public void quitarPasajero() {
        // Implementación para quitar un pasajero de la cola
        if (frente != null) {
            frente = frente.getSiguiente();
            if (frente == null) {
                ultimo = null;
            }
        }
    }

    public int tamañoCola() {
        // Implementación para obtener el tamaño de la cola
        int tamaño = 0;
        Nodo actual = frente;
        while (actual != null) {
            tamaño++;
            actual = actual.getSiguiente();
        }
        return tamaño;
    }

    @Override
    public String toString() {
        return "ColaEnEspera{" +
                "frente=" + frente +
                ", ultimo=" + ultimo +
                '}';
    }
}
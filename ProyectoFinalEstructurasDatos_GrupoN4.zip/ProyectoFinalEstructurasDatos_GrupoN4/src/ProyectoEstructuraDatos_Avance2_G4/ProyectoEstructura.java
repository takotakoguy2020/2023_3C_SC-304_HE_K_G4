
package ProyectoEstructuraDatos_Avance2_G4;


public class ProyectoEstructura {
    public static void main(String[] args) {
    Menu menu = new Menu();
    menu.mostrarMenu();  
         
    }//fin  del metodo main
   
}//fin de la clase main

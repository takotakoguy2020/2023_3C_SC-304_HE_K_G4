
package ProyectoEstructuraDatos_Avance2_G4;


public class Pasajero {

    private String nombre;
    private int id;
    private String destino;
    private boolean discapacidad;

    public Pasajero() {
        this.id = 0;
        this.nombre = "";
        this.destino = "";
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public boolean isDiscapacidad() {
        return discapacidad;
    }

    public void setDiscapacidad(boolean discapacidad) {
        this.discapacidad = discapacidad;
    }



    public String getDestino() {
        return destino;
    }

    public void setDestino(String destino) {
        this.destino = destino;
    }
}

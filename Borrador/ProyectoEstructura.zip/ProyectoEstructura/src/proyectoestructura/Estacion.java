
package proyectoestructura;


public class Estacion {
//Atributos  
public Cola ColaNormal = new Cola();    
public Cola ColaDiscapacitados = new Cola();       


public void PrepararColas(){




}


}

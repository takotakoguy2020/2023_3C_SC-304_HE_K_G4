
package proyectoestructura;


public class ProyectoEstructura {


    public static void main(String[] args) {
   
    
    
    
    
         
    }//fin  del metodo main
   
}//fin de la clase main

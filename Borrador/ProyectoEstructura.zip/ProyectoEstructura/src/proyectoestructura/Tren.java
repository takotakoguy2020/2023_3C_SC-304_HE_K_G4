package proyectoestructura;

public class Tren {
// atributos

    public Pila PilaNormal1 = new Pila();
    public Pila PilaNormal2 = new Pila();
    public Pila PilaDiscapacitados = new Pila();
// Metodos de clase

    public void Suben() {

    }

    public void Bajan() {

    }

}

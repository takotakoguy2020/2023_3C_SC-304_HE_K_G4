
package proyectoestructura;


public class NodoGrafo {
    
}

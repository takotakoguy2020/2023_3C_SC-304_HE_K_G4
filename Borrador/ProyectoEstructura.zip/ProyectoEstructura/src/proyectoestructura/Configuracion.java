
package proyectoestructura;


public class Configuracion {
    
}

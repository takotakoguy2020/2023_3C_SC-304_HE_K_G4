package ProyectoEstructuraDatos_Avance2_G4;

import java.util.EmptyStackException;

public class Tren {
    // Atributos
    public Pila pilaNormal1 = new Pila();
    public Pila pilaNormal2 = new Pila();
    public Pila pilaDiscapacitados = new Pila();

    // Métodos de clase
    public void Suben(Pasajero pasajero, TipoPasajero tipo) {
        switch (tipo) {
            case NORMAL -> {
                if (Math.random() < 0.5) {
                    pilaNormal1.apilar();
                } else {
                    pilaNormal2.apilar();
                }
            }
            case DISCAPACITADO -> pilaDiscapacitados.apilar();
            default -> System.out.println("Tipo de pasajero no reconocido.");
        }
    }

    public void Bajan(TipoPasajero tipo) {
        switch (tipo) {
            case NORMAL -> {
                try {
                    if (Math.random() < 0.5) {
                        pilaNormal1.desapilar();
                    } else {
                        pilaNormal2.desapilar();
                    }
                } catch (EmptyStackException e) {
                    System.out.println("La pila de pasajeros normales está vacía.");
                }
            }
            case DISCAPACITADO -> {
                try {
                    pilaDiscapacitados.desapilar();
                } catch (EmptyStackException e) {
                    System.out.println("La pila de pasajeros discapacitados está vacía.");
                }
            }
            default -> {
                System.out.println("Tipo de pasajero no reconocido.");
            }
        }
    }

    public void iniciarTren() {
        // Lógica para iniciar el tren (si es necesario)
        System.out.println("El tren ha sido iniciado.");
    }

    // Enumeración para representar el tipo de pasajero
    public enum TipoPasajero {
        NORMAL,
        DISCAPACITADO
    }
}

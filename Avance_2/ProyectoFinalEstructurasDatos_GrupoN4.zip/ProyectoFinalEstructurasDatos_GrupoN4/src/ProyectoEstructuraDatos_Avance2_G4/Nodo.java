package ProyectoEstructuraDatos_Avance2_G4;

public class Nodo {
    private Dato elemento;
    private Nodo siguiente;

    public Nodo(Dato elemento) {
        this.elemento = elemento;
        this.siguiente = null;
    }

    // Getters y Setters
    public Dato getElemento() {
        return elemento;
    }

    public void setElemento(Dato elemento) {
        this.elemento = elemento;
    }

    public Nodo getSiguiente() {
        return siguiente;
    }

    public void setSiguiente(Nodo siguiente) {
        this.siguiente = siguiente;
    }

    @Override
    public String toString() {
        return "Nodo{" +
                "elemento=" + elemento +
                '}';
    }
}


package ProyectoEstructuraDatos_Avance2_G4;


public class Estacion {
    private double precioTicket;
    private int numeroEstacion;
    private ColaEnEspera colaEnEspera;

    public Estacion(double precioTicket, int numeroEstacion) {
        this.precioTicket = precioTicket;
        this.numeroEstacion = numeroEstacion;
        this.colaEnEspera = new ColaEnEspera();
    }

    public void iniciarEstacion() {
        System.out.println("La estación " + numeroEstacion + " ha iniciado.");
    }

    public void sumarEstacion() {
        numeroEstacion++;
    }

    public double getPrecioTicket() {
        return precioTicket;
    }

    public void setPrecioTicket(double precioTicket) {
        this.precioTicket = precioTicket;
    }

    public int getNumeroEstacion() {
        return numeroEstacion;
    }

    public void setNumeroEstacion(int numeroEstacion) {
        this.numeroEstacion = numeroEstacion;
    }

    public ColaEnEspera getColaEnEspera() {
        return colaEnEspera;
    }

    public void setColaEnEspera(ColaEnEspera colaEnEspera) {
        this.colaEnEspera = colaEnEspera;
    }

    @Override
    public String toString() {
        return "Estacion{" +
                "precioTicket=" + precioTicket +
                ", numeroEstacion=" + numeroEstacion +
                ", colaEnEspera=" + colaEnEspera +
                '}';
    }
}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ProyectoEstructuraDatos_Avance2_G4;

/**
 *
 * @author deivert.guiltrichs
 */
public class NodoListaDoble {

    private Pasajero dato;
    private NodoListaDoble anterior;
    private NodoListaDoble siguiente;

    public NodoListaDoble(Pasajero dato) {
        this.dato = dato;
    }

    public Pasajero getDato() {
        return dato;
    }

    public void setDato(Pasajero dato) {
        this.dato = dato;
    }

    public NodoListaDoble getAnterior() {
        return anterior;
    }

    public void setAnterior(NodoListaDoble anterior) {
        this.anterior = anterior;
    }

    public NodoListaDoble getSiguiente() {
        return siguiente;
    }

    public void setSiguiente(NodoListaDoble siguiente) {
        this.siguiente = siguiente;
    }

    @Override
    public String toString() {
        return dato.toString();
    }
}

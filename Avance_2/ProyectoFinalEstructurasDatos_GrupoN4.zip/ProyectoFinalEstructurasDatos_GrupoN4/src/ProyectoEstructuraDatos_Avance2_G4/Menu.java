package ProyectoEstructuraDatos_Avance2_G4;

import javax.swing.JOptionPane;

public class Menu {
    ControlArchivos archivos = new ControlArchivos();
    Tren inicio = new Tren();

    private int opcion = 0;

    public void mostrarMenu() {
        while (opcion != 4) {
            opcion = Integer.parseInt(JOptionPane.showInputDialog(null, """
                                                                        Men\u00fa Principal:
                                                                        1 - Cargar
                                                                        2 - Agregar
                                                                        3 - Iniciar Tren
                                                                        4 - Salir
                                                                        Digite una opci\u00f3n para continuar: """));
            switch (opcion) {
                case 1 -> {
                    
                }
                case 2 -> {
                    archivos.agregar();
                }
                case 3 -> {
                    inicio.iniciarTren();
                }
                case 4 -> System.exit(0);

                default -> JOptionPane.showMessageDialog(null, "Opción inválida", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }
}//fin de clase menu


package ProyectoEstructuraDatos_Avance2_G4;

public class Dato {
    private String destino;
    private boolean discapacidad;
    private String origenDestino;
    private String nombrePersona;

    public Dato(String destino, boolean discapacidad, String origenDestino, String nombrePersona) {
        this.destino = destino;
        this.discapacidad = discapacidad;
        this.origenDestino = origenDestino;
        this.nombrePersona = nombrePersona;
    }

    // Getters y Setters
    public String getDestino() {
        return destino;
    }

    public void setDestino(String destino) {
        this.destino = destino;
    }

    public boolean isDiscapacidad() {
        return discapacidad;
    }

    public void setDiscapacidad(boolean discapacidad) {
        this.discapacidad = discapacidad;
    }

    public String getOrigenDestino() {
        return origenDestino;
    }

    public void setOrigenDestino(String origenDestino) {
        this.origenDestino = origenDestino;
    }

    public String getNombrePersona() {
        return nombrePersona;
    }

    public void setNombrePersona(String nombrePersona) {
        this.nombrePersona = nombrePersona;
    }

    @Override
    public String toString() {
        return "Dato{" +
                "destino='" + destino + '\'' +
                ", discapacidad=" + discapacidad +
                ", origenDestino='" + origenDestino + '\'' +
                ", nombrePersona='" + nombrePersona + '\'' +
                '}';
    }
}

package Proyecto_Avance1_G4;

public class Dato {
    
}

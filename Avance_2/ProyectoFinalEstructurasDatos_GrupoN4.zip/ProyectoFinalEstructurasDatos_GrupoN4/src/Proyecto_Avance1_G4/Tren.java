package Proyecto_Avance1_G4;

public class Tren {
    //Método ingreso()
    //Método desalojo()
    //Método iniciarTren()
}//Fin de la clase

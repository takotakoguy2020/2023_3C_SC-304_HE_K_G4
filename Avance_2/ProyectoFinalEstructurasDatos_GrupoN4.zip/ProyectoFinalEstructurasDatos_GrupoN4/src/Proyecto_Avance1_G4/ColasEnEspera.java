package Proyecto_Avance1_G4;

public class ColasEnEspera {
    //Método iniciarColaEspera();
}//Fin de la clase

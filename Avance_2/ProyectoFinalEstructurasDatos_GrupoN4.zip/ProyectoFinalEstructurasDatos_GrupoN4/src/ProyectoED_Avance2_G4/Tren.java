package ProyectoED_Avance2_G4;

public class Tren {
    private Grafo ruta;
    private ListaCircularDoble<Vagon> vagones;
    private Cola<Pasajero> colaDiscapacitados;
    private Cola<Pasajero> colaNoDiscapacitados;
    private double costoPorKilometro;
    private double kilometrajeTotal;

    public Tren(Grafo ruta, double costoPorKilometro, int tamañoMaximoColas) {
        this.ruta = ruta;
        this.vagones = new ListaCircularDoble<>();
        this.colaDiscapacitados = new Cola<>(tamañoMaximoColas);
        this.colaNoDiscapacitados = new Cola<>(tamañoMaximoColas);
        this.costoPorKilometro = costoPorKilometro;
        this.kilometrajeTotal = 0;

        // Inicializar los vagones del tren
        for (int i = 0; i < 3; i++) {
            Pila<Asiento> pilaAsientos = new Pila<>(); // 3 asientos por fila
            for (int j = 0; j < 3; j++) {
                pilaAsientos.apilar(new Asiento());
            }
            Vagon vagon = new Vagon(pilaAsientos);
            vagones.insertarAlFinal(vagon);
        }
    }

    public void moverTren(int origen, int destino) {
        int distancia = ruta.obtenerDistancia(origen, destino);
        int tiempoViaje = 10; // Asume un tiempo de viaje constante para el ejemplo

        // Mover el tren a la siguiente estación
        System.out.println("Moviendo el tren de " + ruta.getEstacion(origen).getNombre() +
                " a " + ruta.getEstacion(destino).getNombre() + " - " +
                distancia + " km, " + tiempoViaje + " minutos");

        // Atender a los pasajeros en la estación de destino
        // Simplemente imprimir un mensaje en este ejemplo
        System.out.println("Atendiendo a los pasajeros en la estación de " + ruta.getEstacion(destino).getNombre());

        // Calcular el costo del boleto y actualizar el kilometraje total
        double costoViaje = distancia * costoPorKilometro;
        kilometrajeTotal += distancia;

        System.out.println("Costo del boleto para este tramo: $" + costoViaje);
        System.out.println("Kilometraje total recorrido: " + kilometrajeTotal + " km\n");
    }

    public void realizarViaje() {
        // Supongamos que la ruta es una lista de estaciones
        Estacion[] estaciones = ruta.getEstaciones();

        // El tren se mueve desde la primera estación hasta la última
        for (int i = 0; i < estaciones.length - 1; i++) {
            moverTren(i, i + 1);
        }

        // Al finalizar el viaje, se calcula el costo total del boleto
        double costoTotal = calcularCostoTotal();
        System.out.println("Costo total del boleto: $" + costoTotal);
    }

    private double calcularCostoTotal() {
        return kilometrajeTotal * costoPorKilometro;
    }
}




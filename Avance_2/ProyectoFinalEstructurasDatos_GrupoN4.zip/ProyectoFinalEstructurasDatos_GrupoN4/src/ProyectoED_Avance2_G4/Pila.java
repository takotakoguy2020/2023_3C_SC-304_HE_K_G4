package ProyectoED_Avance2_G4;

public class Pila<T> {
    private Nodo<T> tope;
    private int tamañoMaximo;

    public Pila() {
        this.tope = null;
        this.tamañoMaximo = tamañoMaximo;
    }

    public boolean estaVacia() {
        return tope == null;
    }

    public boolean estaLlena() {
        return contarElementos() == tamañoMaximo;
    }

    public void apilar(T dato) {
        if (!estaLlena()) {
            Nodo<T> nuevoNodo = new Nodo<>(dato);
            nuevoNodo.setSiguiente(tope);
            tope = nuevoNodo;
        } else {
            System.out.println("La pila está llena. No se puede apilar más elementos.");
        }
    }

    public T desapilar() {
        if (!estaVacia()) {
            T datoDesapilado = tope.getDato();
            tope = tope.getSiguiente();
            return datoDesapilado;
        } else {
            System.out.println("La pila está vacía. No se puede desapilar.");
            return null;
        }
    }

    public T obtenerTope() {
        return estaVacia() ? null : tope.getDato();
    }

    private int contarElementos() {
        int contador = 0;
        Nodo<T> actual = tope;

        while (actual != null && contador < tamañoMaximo) {
            contador++;
            actual = actual.getSiguiente();
        }

        return contador;
    }

    public int obtenerCantidadElementos() {
        int contador = 0;
        Nodo<T> actual = tope;

        while (actual != null) {
            contador++;
            actual = actual.getSiguiente();
        }

        return contador;
    }

    public void vaciar() {
        tope = null;
    }

}



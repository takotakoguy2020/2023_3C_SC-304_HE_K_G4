package ProyectoED_Avance2_G4;

public enum EstadoPasajero {
    EN_COLA,
    EN_CAMINO,
    COMPLETADO
}
package ProyectoED_Avance2_G4;

public class Grafo {
    private int[][] matrizAdyacencia;
    private Estacion[] estaciones;

    public Grafo(int numEstaciones) {
        this.estaciones = new Estacion[numEstaciones];
        this.matrizAdyacencia = new int[numEstaciones][numEstaciones];

        for (int i = 0; i < numEstaciones; i++) {
            for (int j = 0; j < numEstaciones; j++) {
                matrizAdyacencia[i][j] = 0;
            }
        }
    }

    public void agregarArista(int origen, int destino, int distancia) {
        matrizAdyacencia[origen][destino] = distancia;
        matrizAdyacencia[destino][origen] = distancia;
    }

    public int obtenerDistancia(int origen, int destino) {
        // obtener la distancia entre el origen y el destino
        return matrizAdyacencia[origen][destino];
    }

    public void imprimirMatrizAdyacencia() {
        // imprimir la matriz de adyacencia (solo para propósitos de depuración)
        for (int i = 0; i < estaciones.length; i++) {
            for (int j = 0; j < estaciones.length; j++) {
                System.out.print(matrizAdyacencia[i][j] + " ");
            }
            System.out.println();
        }
    }

    public Estacion getEstacion(int indice) {
        return estaciones[indice];
    }

    public Estacion[] getEstaciones() {
        return estaciones;
    }

    public static void main(String[] args) {
        int numEstaciones = 7;
        Grafo grafo = new Grafo(numEstaciones);

        grafo.agregarArista(0, 1, 10);  // Alajuela - Limon
        grafo.agregarArista(1, 2, 50);  // Limon - Cartago
        grafo.agregarArista(2, 3, 30);  // Cartago - Heredia
        grafo.agregarArista(3, 4, 25);  // Heredia - San Jose
        grafo.agregarArista(4, 5, 40);  // San Jose - Puntarenas
        grafo.agregarArista(5, 6, 100); // Puntarenas - Guanacaste
        grafo.agregarArista(6, 0, 40);  // Guanacaste - Alajuela

        grafo.imprimirMatrizAdyacencia();
    }
}


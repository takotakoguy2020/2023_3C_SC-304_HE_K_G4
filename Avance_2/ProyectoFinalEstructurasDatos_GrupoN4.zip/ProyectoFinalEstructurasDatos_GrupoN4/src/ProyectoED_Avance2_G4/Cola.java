package ProyectoED_Avance2_G4;

public class Cola<T> {
    private Nodo<T> frente;
    private Nodo<T> finalCola;
    private int tamañoMaximo;

    public Cola(int tamañoMaximo) {
        this.frente = null;
        this.finalCola = null;
        this.tamañoMaximo = tamañoMaximo;
    }

    public boolean estaVacia() {
        return frente == null;
    }

    public boolean estaLlena() {
        return contarElementos() == tamañoMaximo;
    }

    public void encolar(T dato) {
        if (!estaLlena()) {
            Nodo<T> nuevoNodo = new Nodo<>(dato);
            if (estaVacia()) {
                frente = nuevoNodo;
                finalCola = nuevoNodo;
            } else {
                finalCola.setSiguiente(nuevoNodo);
                finalCola = nuevoNodo;
            }
        } else {
            System.out.println("La cola está llena. No se pueden encolar más elementos.");
        }
    }

    public T desencolar() {
        if (!estaVacia()) {
            T datoDesencolado = frente.getDato();
            frente = frente.getSiguiente();
            if (frente == null) {
                finalCola = null;
            }
            return datoDesencolado;
        } else {
            System.out.println("La cola está vacía. No se pueden desencolar más elementos.");
            return null;
        }
    }

    public T obtenerFrente() {
        return estaVacia() ? null : frente.getDato();
    }

    private int contarElementos() {
        int contador = 0;
        Nodo<T> actual = frente;

        while (actual != null) {
            contador++;
            actual = actual.getSiguiente();
        }

        return contador;
    }
}




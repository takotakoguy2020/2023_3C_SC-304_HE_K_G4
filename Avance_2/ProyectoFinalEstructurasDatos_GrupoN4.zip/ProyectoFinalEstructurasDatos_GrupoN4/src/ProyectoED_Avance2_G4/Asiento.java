package ProyectoED_Avance2_G4;

public class Asiento {
    private boolean ocupado;

    public Asiento() {
        this.ocupado = false;
    }

    public boolean estaOcupado() {
        return ocupado;
    }

    public boolean ocupar() {
        if (!ocupado) {
            ocupado = true;
            System.out.println("Asiento ocupado correctamente.");
            return true;
        } else {
            System.out.println("El asiento ya está ocupado.");
            return false;
        }
    }

    public boolean liberar() {
        if (ocupado) {
            ocupado = false;
            System.out.println("Asiento liberado correctamente.");
            return true;
        } else {
            System.out.println("El asiento ya está libre.");
            return false;
        }
    }

}



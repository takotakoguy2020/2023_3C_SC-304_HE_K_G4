package ProyectoED_Avance2_G4;

public class Estacion {
    private String nombre;
    private int distancia;
    private int tiempoViaje;
    private Pila<Pasajero> pilaPasajerosSuben;
    private Pila<Pasajero> pilaPasajerosBajan;

    public Estacion(String nombre, int distancia, int tiempoViaje) {
        this.nombre = nombre;
        this.distancia = distancia;
        this.tiempoViaje = tiempoViaje;
        this.pilaPasajerosSuben = new Pila<>();
        this.pilaPasajerosBajan = new Pila<>();
    }

    public String getNombre() {
        return nombre;
    }

    public int getDistancia() {
        return distancia;
    }

    public int getTiempoViaje() {
        return tiempoViaje;
    }

    public Pila<Pasajero> getPilaPasajerosSuben() {
        return pilaPasajerosSuben;
    }

    public Pila<Pasajero> getPilaPasajerosBajan() {
        return pilaPasajerosBajan;
    }

    public void agregarPasajeroSube(Pasajero pasajero) {
        pilaPasajerosSuben.apilar(pasajero);
    }

    public void agregarPasajeroBaja(Pasajero pasajero) {
        pilaPasajerosBajan.apilar(pasajero);
    }

    public void atenderPasajeros() {
        desalojarPasajeros();
        cargarPasajeros();
    }

    private void desalojarPasajeros() {
        while (!pilaPasajerosBajan.estaVacia()) {
            Pasajero pasajero = pilaPasajerosBajan.desapilar();
            System.out.println("Pasajero desalojado en " + nombre + ": " + pasajero.getNombre());
        }
    }

    private void cargarPasajeros() {
        while (!pilaPasajerosSuben.estaVacia()) {
            Pasajero pasajero = pilaPasajerosSuben.desapilar();
            // Implementa la lógica para cargar pasajeros
            System.out.println("Pasajero cargado en " + nombre + ": " + pasajero.getNombre());
        }
    }

}


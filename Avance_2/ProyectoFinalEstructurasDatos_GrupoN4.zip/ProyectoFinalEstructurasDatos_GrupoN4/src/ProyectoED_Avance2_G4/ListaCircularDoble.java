package ProyectoED_Avance2_G4;

public class ListaCircularDoble<T> {
    private Nodo<T> inicio;

    public ListaCircularDoble() {
        this.inicio = null;
    }

    public boolean estaVacia() {
        return inicio == null;
    }

    public void insertarAlInicio(T dato) {
        Nodo<T> nuevoNodo = new Nodo<>(dato);
        if (estaVacia()) {
            nuevoNodo.setSiguiente(nuevoNodo);
            nuevoNodo.setAnterior(nuevoNodo);
            inicio = nuevoNodo;
        } else {
            Nodo<T> ultimo = inicio.getAnterior();
            nuevoNodo.setSiguiente(inicio);
            nuevoNodo.setAnterior(ultimo);
            inicio.setAnterior(nuevoNodo);
            ultimo.setSiguiente(nuevoNodo);
            inicio = nuevoNodo;
        }
    }

    public void insertarAlFinal(T dato) {
        Nodo<T> nuevoNodo = new Nodo<>(dato);
        if (estaVacia()) {
            nuevoNodo.setSiguiente(nuevoNodo);
            nuevoNodo.setAnterior(nuevoNodo);
            inicio = nuevoNodo;
        } else {
            Nodo<T> ultimo = inicio.getAnterior();
            nuevoNodo.setSiguiente(inicio);
            nuevoNodo.setAnterior(ultimo);
            inicio.setAnterior(nuevoNodo);
            ultimo.setSiguiente(nuevoNodo);
        }
    }

    public void eliminarAlInicio() {
        if (!estaVacia()) {
            Nodo<T> ultimo = inicio.getAnterior();
            if (inicio == ultimo) {
                inicio = null;
            } else {
                inicio = inicio.getSiguiente();
                ultimo.setSiguiente(inicio);
                inicio.setAnterior(ultimo);
            }
        }
    }

    public void eliminarAlFinal() {
        if (!estaVacia()) {
            Nodo<T> ultimo = inicio.getAnterior();
            if (inicio == ultimo) {
                inicio = null;
            } else {
                Nodo<T> penultimo = ultimo.getAnterior();
                penultimo.setSiguiente(inicio);
                inicio.setAnterior(penultimo);
            }
        }
    }

    public int obtenerLongitud() {
        int longitud = 0;
        if (!estaVacia()) {
            Nodo<T> actual = inicio;
            do {
                longitud++;
                actual = actual.getSiguiente();
            } while (actual != inicio);
        }
        return longitud;
    }

    public T obtenerElementoEnPosicion(int posicion) {
        Nodo<T> nodoEnPosicion = obtenerNodoEnPosicion(posicion);
        return (nodoEnPosicion != null) ? nodoEnPosicion.getDato() : null;
    }

    public Nodo<T> obtenerNodoEnPosicion(int posicion) {
        if (posicion < 0 || estaVacia()) {
            return null;
        }

        Nodo<T> actual = inicio;
        for (int i = 0; i < posicion; i++) {
            actual = actual.getSiguiente();
            if (actual == inicio) {
                return null; // la posicion excede el tamano de la lista
            }
        }
        return actual;
    }
}




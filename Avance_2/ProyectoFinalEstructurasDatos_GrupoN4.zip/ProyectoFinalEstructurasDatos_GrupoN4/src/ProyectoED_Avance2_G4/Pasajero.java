package ProyectoED_Avance2_G4;

public class Pasajero {
    private String nombre;
    private boolean discapacidad;
    private EstadoPasajero estado;

    public Pasajero(String nombre, boolean discapacidad) {
        this.nombre = nombre;
        this.discapacidad = discapacidad;
        this.estado = EstadoPasajero.EN_COLA;
    }

    public String getNombre() {
        return nombre;
    }

    public boolean tieneDiscapacidad() {
        return discapacidad;
    }

    public EstadoPasajero getEstado() {
        return estado;
    }

    public void abordarTren() {
        if (estado == EstadoPasajero.EN_COLA) {
            System.out.println("El pasajero " + nombre + " ha abordado el tren.");
            estado = EstadoPasajero.EN_CAMINO;
            if (discapacidad) {
                solicitarAsistencia();
            }
        } else {
            System.out.println("El pasajero " + nombre + " ya ha abordado el tren.");
        }
    }

    public void desembarcarTren() {
        if (estado == EstadoPasajero.EN_CAMINO) {
            System.out.println("El pasajero " + nombre + " ha desembarcado del tren.");
            estado = EstadoPasajero.COMPLETADO;
        } else {
            System.out.println("El pasajero " + nombre + " no puede desembarcar en este momento.");
        }
    }

    public void solicitarAsistencia() {
        if (discapacidad && estado == EstadoPasajero.EN_CAMINO) {
            System.out.println("El pasajero " + nombre + " ha solicitado asistencia.");
        } else if (estado == EstadoPasajero.EN_COLA) {
            System.out.println("El pasajero " + nombre + " aún no ha abordado el tren para solicitar asistencia.");
        } else {
            System.out.println("El pasajero " + nombre + " no tiene discapacidad o ya ha completado su viaje.");
        }
    }

    public void cambiarEstado(EstadoPasajero nuevoEstado) {
        this.estado = nuevoEstado;
    }

    @Override
    public String toString() {
        return "Pasajero{" +
                "nombre='" + nombre + '\'' +
                ", discapacidad=" + discapacidad +
                ", estado=" + estado +
                '}';
    }
}

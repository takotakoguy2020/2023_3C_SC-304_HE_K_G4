package ProyectoED_Avance2_G4;

public class Vagon {
    private ListaCircularDoble<Pila<Asiento>> filasAsientos;

    public Vagon(Pila<Asiento> pilaAsientos) {
        this.filasAsientos = new ListaCircularDoble<>();

        for (int i = 0; i < 3; i++) {
            pilaAsientos = new Pila<Asiento>();
            for (int j = 0; j < 3; j++) {
                pilaAsientos.apilar(new Asiento());
            }
            filasAsientos.insertarAlFinal(pilaAsientos);
        }
    }

    public boolean hayAsientosDisponibles() {
        for (int i = 0; i < filasAsientos.obtenerLongitud(); i++) {
            Pila<Asiento> fila = filasAsientos.obtenerElementoEnPosicion(i);
            if (fila != null && !fila.estaLlena()) {
                return true;
            }
        }
        return false;
    }

    public Asiento obtenerAsientoDisponible() {
        for (int i = 0; i < filasAsientos.obtenerLongitud(); i++) {
            Pila<Asiento> fila = filasAsientos.obtenerElementoEnPosicion(i);
            if (fila != null && !fila.estaLlena()) {
                return fila.obtenerTope();
            }
        }
        return null; // no hay asientos
    }

    public void ocuparAsiento(int fila) {
        if (fila >= 0 && fila < filasAsientos.obtenerLongitud()) {
            Pila<Asiento> pilaFila = filasAsientos.obtenerElementoEnPosicion(fila);
            if (pilaFila != null && !pilaFila.estaLlena()) {
                pilaFila.desapilar();
            } else {
                System.out.println("La fila está llena. No se pueden ocupar más asientos.");
            }
        } else {
            System.out.println("Fila no válida.");
        }
    }

    public void liberarAsiento(int fila, Asiento asiento) {
        if (fila >= 0 && fila < filasAsientos.obtenerLongitud()) {
            Pila<Asiento> pilaFila = filasAsientos.obtenerElementoEnPosicion(fila);
            if (pilaFila != null) {
                pilaFila.apilar(asiento);
            }
        } else {
            System.out.println("Fila no válida.");
        }
    }
}


